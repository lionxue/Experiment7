package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;
import dao.UserDao;
import utils.DBUtils;

public class LoginServlet extends HttpServlet {

	DBUtils db=new DBUtils();
	UserDao userDao=new UserDao();
	
	private static final long serialVersionUID=1L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		Connection con=null;
		try{
			
			User user=new User();
			user.setUsername(username);
			user.setPassword(password);
			con=db.getCon();
			User currentUser=userDao.login(con, user);
			
			if(currentUser==null){
				request.setAttribute("error", "�û��������������");
				request.setAttribute("username", username);
				request.setAttribute("password", password);
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}else{
				HttpSession session=request.getSession();
				session.setAttribute("currentUser", currentUser);
				response.sendRedirect("welcome.jsp");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	

}
