package com.listener;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;

public class MyServletContextAttributeListener implements ServletContextAttributeListener
{

    public void attributeAdded(ServletContextAttributeEvent arg0)
    {
        System.out.println("attributeAdd ");
        System.out.println(arg0.getName() + ":" + arg0.getValue());
        
    }

    public void attributeRemoved(ServletContextAttributeEvent arg0)
    {
        System.out.println("attributeRemoved");
        System.out.println(arg0.getName() + ":" + arg0.getValue());//valueֵ����ʾ֮ǰ�� ֵ
    }

    public void attributeReplaced(ServletContextAttributeEvent arg0)
    {
        System.out.println("attributeRepaced");
        System.out.println(arg0.getName() + ":" + arg0.getValue());//valueֵ����ʾ֮ǰ�� ֵ
        
    }
    
}